source devel/setup.bash


rosrun beginner_tutorials tes_marker_new2.py
