source devel/setup.bash


rosrun beginner_tutorials exportpythontoexcel.py
