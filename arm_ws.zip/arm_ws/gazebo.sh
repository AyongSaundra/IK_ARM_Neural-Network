clear
source devel/setup.bash
roslaunch arm_gazebo arm_gazebo.launch
