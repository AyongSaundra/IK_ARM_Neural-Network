
"use strict";

let NN = require('./NN.js');

module.exports = {
  NN: NN,
};
