clear

source devel/setup.bash

roslaunch arm_description arm_rviz.launch
